export class Button {
  public text: string;
  public style: string;
  constructor(text: string, style: string) {
    this.text = text;
    this.style = style;
  }
}
