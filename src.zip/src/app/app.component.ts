import { Component } from '@angular/core';
import { Person } from './person';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  persons: Array<Person> = [];

  constructor() {
    for(let i:number =0;i<10;i++)
      this.persons.push(new Person(i.toString(),i.toString(),i));
    
  }
 
}
